const mongoose = require('mongoose');

const symptomCheckSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    symptoms: {
        type: String,
        required: true
    },
    analysis: {
        type: String,
        required: true
    },
    language: {
        type: String,
        enum: ['en', 'hi'],
        default: 'en'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('SymptomCheck', symptomCheckSchema);
