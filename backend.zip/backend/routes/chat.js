const express = require('express');
const Chat = require('../models/Chat');
const { authenticate } = require('../middleware/auth');
const { generateChatResponse } = require('../services/gemini');
const router = express.Router();

// @route   POST /api/chat
// @desc    Save chat message
// @access  Private
router.post('/', authenticate, async (req, res) => {
    try {
        const { message, response, language } = req.body;

        if (!message || !response) {
            return res.status(400).json({
                success: false,
                message: 'Message and response are required'
            });
        }

        const chat = new Chat({
            userId: req.user._id,
            message,
            response,
            language: language || 'en'
        });

        await chat.save();

        res.status(201).json({
            success: true,
            message: 'Chat saved successfully',
            chat
        });
    } catch (error) {
        console.error('Save chat error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @route   POST /api/chat/generate
// @desc    Generate chat response using Gemini AI
// @access  Private
router.post('/generate', authenticate, async (req, res) => {
    try {
        const { message, language } = req.body;

        if (!message) {
            return res.status(400).json({
                success: false,
                message: 'Message is required'
            });
        }

        // Generate response using Gemini
        const response = await generateChatResponse(message, language || 'en');

        // Save to database
        const chat = new Chat({
            userId: req.user._id,
            message,
            response,
            language: language || 'en'
        });
        await chat.save();

        res.json({
            success: true,
            response,
            chat
        });
    } catch (error) {
        console.error('Generate chat error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to generate chat response',
            error: error.message
        });
    }
});

// @route   GET /api/chat
// @desc    Get user's chat history
// @access  Private
router.get('/', authenticate, async (req, res) => {
    try {
        const chats = await Chat.find({ userId: req.user._id })
            .sort({ createdAt: -1 })
            .limit(50);

        res.json({
            success: true,
            count: chats.length,
            chats
        });
    } catch (error) {
        console.error('Get chats error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @route   DELETE /api/chat/:id
// @desc    Delete a chat message
// @access  Private
router.delete('/:id', authenticate, async (req, res) => {
    try {
        const chat = await Chat.findOne({
            _id: req.params.id,
            userId: req.user._id
        });

        if (!chat) {
            return res.status(404).json({
                success: false,
                message: 'Chat not found'
            });
        }

        await chat.deleteOne();

        res.json({
            success: true,
            message: 'Chat deleted successfully'
        });
    } catch (error) {
        console.error('Delete chat error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

module.exports = router;
