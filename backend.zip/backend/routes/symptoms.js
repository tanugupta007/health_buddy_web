const express = require('express');
const SymptomCheck = require('../models/SymptomCheck');
const { authenticate } = require('../middleware/auth');
const { generateSymptomAnalysis } = require('../services/gemini');
const router = express.Router();

// @route   POST /api/symptoms
// @desc    Save symptom check
// @access  Private
router.post('/', authenticate, async (req, res) => {
    try {
        const { symptoms, analysis, language } = req.body;

        if (!symptoms || !analysis) {
            return res.status(400).json({
                success: false,
                message: 'Symptoms and analysis are required'
            });
        }

        const symptomCheck = new SymptomCheck({
            userId: req.user._id,
            symptoms,
            analysis,
            language: language || 'en'
        });

        await symptomCheck.save();

        res.status(201).json({
            success: true,
            message: 'Symptom check saved successfully',
            symptomCheck
        });
    } catch (error) {
        console.error('Save symptom check error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @route   POST /api/symptoms/analyze
// @desc    Analyze symptoms using Gemini AI
// @access  Private
router.post('/analyze', authenticate, async (req, res) => {
    try {
        const { symptoms, language } = req.body;

        if (!symptoms) {
            return res.status(400).json({
                success: false,
                message: 'Symptoms are required'
            });
        }

        // Generate analysis using Gemini
        const analysis = await generateSymptomAnalysis(symptoms, language || 'en');

        // Save to database
        const symptomCheck = new SymptomCheck({
            userId: req.user._id,
            symptoms,
            analysis,
            language: language || 'en'
        });
        await symptomCheck.save();

        res.json({
            success: true,
            analysis,
            symptomCheck
        });
    } catch (error) {
        console.error('Analyze symptoms error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to analyze symptoms',
            error: error.message
        });
    }
});

// @route   GET /api/symptoms
// @desc    Get user's symptom check history
// @access  Private
router.get('/', authenticate, async (req, res) => {
    try {
        const symptomChecks = await SymptomCheck.find({ userId: req.user._id })
            .sort({ createdAt: -1 })
            .limit(50);

        res.json({
            success: true,
            count: symptomChecks.length,
            symptomChecks
        });
    } catch (error) {
        console.error('Get symptom checks error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

// @route   GET /api/symptoms/:id
// @desc    Get specific symptom check
// @access  Private
router.get('/:id', authenticate, async (req, res) => {
    try {
        const symptomCheck = await SymptomCheck.findOne({
            _id: req.params.id,
            userId: req.user._id
        });

        if (!symptomCheck) {
            return res.status(404).json({
                success: false,
                message: 'Symptom check not found'
            });
        }

        res.json({
            success: true,
            symptomCheck
        });
    } catch (error) {
        console.error('Get symptom check error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
});

module.exports = router;
