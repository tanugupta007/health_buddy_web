const { GoogleGenerativeAI } = require('@google/generative-ai');

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '');

// Get the model instance
function getModel() {
    if (!process.env.GEMINI_API_KEY) {
        throw new Error('GEMINI_API_KEY is not set in environment variables');
    }
    return genAI.getGenerativeModel({ model: 'gemini-pro' });
}

// Generate chat response
async function generateChatResponse(message, language = 'en') {
    try {
        const model = getModel();
        
        const systemPrompt = language === 'hi' 
            ? 'आप एक स्वास्थ्य सहायक हैं। स्वास्थ्य संबंधी प्रश्नों का उत्तर हिंदी में दें। सामान्य स्वास्थ्य सलाह दें, लेकिन गंभीर लक्षणों के लिए डॉक्टर से परामर्श करने की सलाह दें।'
            : 'You are a health assistant. Answer health-related questions in English. Provide general health advice, but always recommend consulting a doctor for serious symptoms.';

        const prompt = `${systemPrompt}\n\nUser: ${message}\n\nAssistant:`;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error('Gemini chat error:', error);
        throw new Error('Failed to generate chat response');
    }
}

// Generate symptom analysis
async function generateSymptomAnalysis(symptoms, language = 'en') {
    try {
        const model = getModel();
        
        const systemPrompt = language === 'hi'
            ? 'आप एक चिकित्सा सहायक हैं। लक्षणों का विश्लेषण हिंदी में करें। संभावित कारण, सामान्य सुझाव और कब डॉक्टर से मिलना चाहिए, इसकी जानकारी दें। याद रखें: यह केवल सामान्य जानकारी है, निदान नहीं।'
            : 'You are a medical assistant. Analyze symptoms in English. Provide possible causes, general suggestions, and when to see a doctor. Remember: This is general information only, not a diagnosis.';

        const prompt = `${systemPrompt}\n\nSymptoms: ${symptoms}\n\nAnalysis:`;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        return response.text();
    } catch (error) {
        console.error('Gemini symptom analysis error:', error);
        throw new Error('Failed to generate symptom analysis');
    }
}

module.exports = {
    generateChatResponse,
    generateSymptomAnalysis
};

